namespace Project3.Models
{
    public class CoursesModel {
    
            public string courseID { get; set; }
            public string title { get; set; }
            public string description { get; set; }
    }
}
